// Vyntra public client configuration.
// Replace these two placeholders with values from Supabase > Project Settings > API.
// The anon/public key is designed for browser use when Row Level Security is enabled.
// NEVER put a service_role key, database password, or provider secret in this file.
window.VYNTRA_SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
window.VYNTRA_SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_PUBLIC_KEY";
